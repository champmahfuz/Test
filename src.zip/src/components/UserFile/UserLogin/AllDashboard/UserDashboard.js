import React from 'react';

const UserDashboard = () => {
    return (
        <div>
            <h2>This is User Dashboard</h2>
        </div>
    );
};

export default UserDashboard;