import "./UserSidebar.scss"
import DashboardIcon from "@mui/icons-material/Dashboard";
import { Link } from "react-router-dom";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import BookIcon from '@mui/icons-material/Book';
import BookOnlineIcon from '@mui/icons-material/BookOnline';
import ReviewsIcon from '@mui/icons-material/Reviews';
import PaidIcon from '@mui/icons-material/Paid';
import MyBookingOption from "../MyBookingOption/MyBookingOption";
import AllBookingOption from "../AllBookingOption/AllBookingOption";
import ReviewOption from "../Review/ReviewOption";




export const UserSidebar = () => {
  return (
    <div className="sidebar">
        <div className='top'>
            <Link to="/">
            <span className="logo">Othooy</span>
            </Link>
            </div>
            <hr />
        <div className='center'>
            <ul>
                <p className="title">MAIN</p> 
                <li>
                    <DashboardIcon className="icon"/>
                    <span>Dashboard</span>
                </li>
                <p className="title">LISTS</p>
                <li>
                    <PersonOutlineIcon className="icon"/>
                    <span>Users</span>
                </li>
            
                <li>
                    <BookIcon className="icon"/>
                    <MyBookingOption/>
                </li>
                <li>
                    <BookOnlineIcon className="icon"/>
                    <AllBookingOption/>
                </li>
                <li>
                    <ReviewsIcon className="icon"/>
                    <ReviewOption/>
                </li>
                <li>
                    <PaidIcon className="icon"/>
                    <span>Payment</span>
                </li>
                <li>
                    <AddShoppingCartIcon className="icon"/>
                    <span>Add To Cart</span>
                </li>
                <li>   
                <ExitToAppIcon className="icon"/>
                    <span>LogOut</span>
                </li>
                
                                

            </ul>
        </div>
        <div className='bottom'>
            <div className="colorOption"></div>
            <div className="colorOption"></div>
        </div>
        </div>

  
  );
};

export default UserSidebar;
