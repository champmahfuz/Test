import React from 'react';

const TestComponent = () => {
    return (
        <div>
            <h2>TestComponent</h2>
        </div>
    );
};

export default TestComponent;