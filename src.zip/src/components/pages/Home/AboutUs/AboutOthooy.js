import React from 'react';

const AboutOthooy = () => {
    return (
        <div>

        </div>
    );
};

export default AboutOthooy;