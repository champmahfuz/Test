import React from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import logo from '../../../../images/logo.png';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import { Link } from 'react-router-dom';
import { Container, Typography } from '@mui/material';
import './Footer.css'
import { useForm } from 'react-hook-form';
import axios from 'axios';
import paymentMethod from '../../../../images/paymentMethod.png'

const SubscribeButton = styled(Button)({
    fontSize: 16,
    lineHeight: 1.5,
    backgroundColor: 'whitesmoke',
    '&:hover': {
        backgroundColor: 'whitesmoke',
    },
    '&:active': {
        boxShadow: 'none',
        backgroundColor: 'whitesmoke',
    },
});


const Footer = () => {
    // const [subscribes, setSubscribes] = useState([]); 
    // useEffect(() => {
    //     fetch('http://localhost:5000/subscribes')
    //         .then(res => res.json())
    //         .then(data => setSubscribes(data))

    // }, [])

    const { register, handleSubmit, reset } = useForm();
    const onSubmit = (data) => {
        // const subscribeId = subscribes.map(subscribe => subscribe.subscribe);

        if (data.subscribe) {
            axios.post('http://localhost:5000/subscribes', data)
                .then(res => {
                    if (res.data.insertedId) {
                        alert('Added successfully');
                        reset();

                    }
                })
        } else {
            alert('tomar email ache');
        }


    }
    return (
        <Box sx={ { pt: 10, pb: 4, bgcolor: "#f5f5f5" } }>
            <Container>
                <Grid container spacing={ { xs: 2, sm: 4, md: 6 } } >
                    <Grid item xs={ 12 } sm={ 6 } md={ 6 } lg={ 4 }>
                        <Box sx={ { width: "250px", mt: -5, mb: 2 } }>
                            <img src={ logo } width="200px" alt="" />
                        </Box>
                        <Typography sx={ { fontWeight: 500 } }>Othooy was founded in 2022 by the skylight Travel Agency LTD</Typography>
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 6 } lg={ 2.6 }>
                        <Typography sx={ { lineHeight: 2, fontWeight: 600, fontSize: "20px", color: '#26272B' } }>
                            EUROPE
                        </Typography>
                        <Typography sx={ { lineHeight: 2 } } className='footer-list'>
                            Europe 45 Gloucester Road
                        </Typography>
                        <Typography className='footer-list' sx={ { lineHeight: 2 } }>
                            London DT1M 3BF
                        </Typography>
                        <Typography className='footer-list' sx={ { lineHeight: 2, } }>
                            +44 (0)20 3671 5709
                        </Typography>
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 6 } lg={ 2.6 }>
                        <Typography sx={ { lineHeight: 2, fontWeight: 600, fontSize: "20px", color: '#26272B' } }>
                            ASIA & PACIFIC
                        </Typography>
                        <Typography className='footer-list' sx={ { lineHeight: 2 } }>
                            2473 Red Road Ste 98
                        </Typography>
                        <Typography className='footer-list' sx={ { lineHeight: 2 } }>
                            Singapore SG
                        </Typography>
                        <Typography className='footer-list' sx={ { lineHeight: 2, } }>
                            + 1 623 211 6319
                        </Typography>
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 6 } lg={ 2.6 }>
                        <Typography sx={ { lineHeight: 2, fontWeight: 600, fontSize: "20px", color: '#26272B' } }>
                            NORTH AMERICA
                        </Typography>
                        <Typography className='footer-list' sx={ { lineHeight: 2, fontWeight: 500 } }>
                            +44 (0)20 3671 5709
                        </Typography>
                        <Typography className='footer-list' sx={ { lineHeight: 2 } }>
                            Europe 45 Gloucester Road
                        </Typography>
                        <Typography className='footer-list' sx={ { lineHeight: 2 } }>
                            London DT1M 3BF
                        </Typography>
                    </Grid>
                </Grid>
            </Container>

            <Container>
                <Grid container sx={ { px: 5, pb: 5, pt: 3, mt: 5, bgcolor: '#26272B', borderRadius: 3 } } className="footer-grid">
                    <Grid item xs={ 12 } sm={ 6 } md={ 6 } lg={ 2.6 } sx={ { pt: 2, } }>
                        <Typography sx={ { lineHeight: 2, fontWeight: 600, fontSize: "20px", color: 'white' } }>
                            Get started
                        </Typography>
                        <Link className="link-td-none" to="/Home">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Get started
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/Services">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Private jet
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/SignUp">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Register
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/SignIn">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Sign In
                            </Typography>
                        </Link>
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 6 } lg={ 2.6 } sx={ { pt: 2, } }>
                        <Typography sx={ { lineHeight: 2, fontWeight: 600, fontSize: "20px", color: 'white' } }>
                            How it works
                        </Typography>
                        <Link className="link-td-none" to="/About">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Ways to fly
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/Services">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Ways to buy
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/Home">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Tour Packages
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/Services">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Private Jet Cost
                            </Typography>
                        </Link>
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 6 } lg={ 2.6 } sx={ { pt: 2, } }>
                        <Typography variant="h4" sx={ { mb: 1, color: "white" } }>
                            About us
                        </Typography>
                        <Link className="link-td-none" to="/About">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                About us
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/Blogs">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Blog
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/Contact">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                FAQs
                            </Typography>
                        </Link>
                        <Link className="link-td-none" to="/Courses">
                            <Typography sx={ { lineHeight: 2 } } className='footer-box'>
                                Careers
                            </Typography>
                        </Link>
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 6 } lg={ 4 } sx={ { pt: 2, } }>
                        <Typography sx={ { lineHeight: 2, fontWeight: 600, fontSize: "20px", color: 'white' } }>
                            Newsletter
                        </Typography>
                        <Typography sx={ { color: 'white' } }>
                            Othooy was founded in 2022 by the skylight Travel Agency LTD.
                        </Typography>
                        <Box component='form' onSubmit={ handleSubmit(onSubmit) }>
                            <Box>
                                <input className='input-field' type="email" name="" id="" placeholder="Enter Email"
                                    { ...register("subscribe", { required: true }) }
                                />
                            </Box>
                            <Box>
                                <SubscribeButton sx={ { width: '100%', py: "11px", color: '#26272B' } } variant="contained" type='submit' >
                                    Subscribe Us
                                </SubscribeButton>
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </Container>

            <Container>

                <Grid container spacing={ 2 } sx={ { my: 3 } }>
                    <Grid item xs={ 12 } md={ 6 }>
                        <img src={ paymentMethod } alt="paymentMethod" width={ `70%` } />
                    </Grid>
                    <Grid item xs={ 12 } md={ 6 } sx={ { textAlign: 'right' } }>
                        <Typography >
                            © 2022 Othooy. All rights reserved.
                        </Typography>
                    </Grid>
                </Grid>

            </Container>
        </Box >
    );
};

export default Footer;