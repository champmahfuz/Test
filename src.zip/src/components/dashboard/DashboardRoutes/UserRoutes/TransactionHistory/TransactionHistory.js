import React from 'react';
import Users from '../../../../auth/Users/Users';

const TransactionHistory = () => {
    return (
        <div>
            <h1>TransactionHistory</h1>
            <Users />
        </div>
    );
};

export default TransactionHistory;